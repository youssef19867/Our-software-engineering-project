<?php

class Database {
    private $servername;
    private $username;
    private $password;
    private $database;
    private $conn;

    // Constructor to initialize database connection
    public function __construct($servername, $username, $password, $database) {
        $this->servername = $servername;
        $this->username = $username;
        $this->password = $password;
        $this->database = $database;
        $this->connect();
    }

    // Connect to the database
    private function connect() {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->database);

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    // Update customer data
    public function updateCustomerData($customerId, $new_name, $new_address, $new_contact) {
        $stmt = $this->conn->prepare("UPDATE customers SET FullName=?, Address=?, Contact=? WHERE CustomerID=?");
        if (!$stmt) {
            echo "Error preparing statement: " . $this->conn->error;
            exit;
        }

        $stmt->bind_param("sssi", $new_name, $new_address, $new_contact, $customerId);
        if ($stmt->execute()) {
            echo "success"; // Return success message
        } else {
            echo "Error updating customer data: " . $stmt->error; // Return error message
        }

        $stmt->close();
    }

    // Close database connection
    public function closeConnection() {
        $this->conn->close();
    }
}

// Check if data is received via POST method
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve JSON data from POST request body
    $json_data = file_get_contents("php://input");
    
    // Decode JSON data into associative array
    $data = json_decode($json_data, true);

    // Extract individual fields from the data
    $customerId = $data['CustomerId'];
    $new_name = $data['new_name'];
    $new_address = $data['new_address'];
    $new_contact = $data['new_contact'];

    // Validate input data (optional but recommended)
    if (empty($customerId) || empty($new_name) || empty($new_address) || empty($new_contact)) {
        echo "Error: Please fill in all fields.";
        exit;
    }

    // Create Database object
    $db = new Database("localhost", "root", "", "dr. tarek's pharmacy");

    // Update customer data
    $db->updateCustomerData($customerId, $new_name, $new_address, $new_contact);

    // Close database connection
    $db->closeConnection();
} else {
    // Invalid request method
    echo "Invalid request method";
}
?>
