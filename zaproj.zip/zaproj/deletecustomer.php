<?php
class PharmacyManagement {
    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "dr. tarek's pharmacy";
    public $conn;

    public function __construct() {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->database);

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        } 
    }

   

    public function deleteCustomer($customerId) {
        // Prepare and bind SQL statement for deletion
        $sql = "DELETE FROM customers WHERE CustomerID  = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $customerId);

        // Execute SQL statement
        if ($stmt->execute()) {
            // Check if any rows were affected (indicating successful deletion)
            if ($stmt->affected_rows > 0) {
                echo "Customer with ID $customerId deleted successfully";
            } else {
                echo "No customer found with ID $customerId";
            }
        } else {
            echo "Error deleting customer: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    }

    public function __destruct() {
        mysqli_close($this->conn);
    }
}

// Instantiate the class
$pharmacyManagement = new PharmacyManagement();

// Check if it's a POST request and CustomerId is set
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["CustomerId"])) {
    // Retrieve and sanitize customer ID
    $customerId = mysqli_real_escape_string($pharmacyManagement->conn, $_POST["CustomerId"]);

    // Delete customer
    $pharmacyManagement->deleteCustomer($customerId);
} else {
    echo "Error: Customer ID not provided or invalid request";
}
