<?php
$user='root';
$pass= '';
$db='dr. tarek\'s pharmacy';
$conn= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");
?>