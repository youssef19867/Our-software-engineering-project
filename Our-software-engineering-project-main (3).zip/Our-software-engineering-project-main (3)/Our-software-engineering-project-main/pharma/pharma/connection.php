<?php
$user='root';
$pass= '';
$db='login';
$conn= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");
?>