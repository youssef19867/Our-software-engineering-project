<!DOCTYPE html>
<html>
<head>
    <link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="sales.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="contentheader">
                    <i class="icon-money"></i> Sales
                </div>
                <div style="margin-top: -19px; margin-bottom: 21px;">
                   
                    <button onclick="window.location.href='addproduct.php'" class="btn btn-primary">Insert New Sale</button>
                   
                </div>
                <table class="custom-table" id="resultTable">
                    <thead>
                        <tr>
                            <th> Product Code </th>
                            <th> Generic Name </th>
                            <th> Name </th>
                            <th> Price </th>
                            <th> Qty </th>
                            <th> Amount </th>
                            <th> Profit </th>
                            <th> Actions </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        
                        include('connect.php');

                     
                        $result = $db->query("SELECT * FROM sales_order");

                       
                        if ($result->rowCount() > 0) {
                           
                            while ($row = $result->fetch()) {
                                ?>
                                <tr class="record">
                                   
                                    <td><?php echo $row['product_code']; ?></td>
                                    <td><?php echo $row['gen_name']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['price']; ?></td>
                                    <td><?php echo $row['qty']; ?></td>
                                    <td><?php echo $row['amount']; ?></td>
                                    <td><?php echo $row['profit']; ?></td>
                                    
                                    <td>
                                        <a href="update.php?id=<?php echo $row['transaction_id']; ?>" class="btn btn-primary btn-sm">Edit</a>
                                       <a href="deletesales.php?id=<?php echo $row['transaction_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            // No rows found
                            echo "<tr><td colspan='8'>No sales records found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
