<!DOCTYPE html>
<html>
<head>
    <link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="sales.css"> 
</head>
<body>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="contentheader">
                    <i class="icon-money"></i> Delete Product
                </div>
                <div style="margin-top: -19px; margin-bottom: 21px;"></div>
                <?php

                class Database {
                    private $conn;
                    public function getConnection() {
                        try {
                            $this->conn = new PDO("mysql:host=localhost;dbname=dr. tarek's pharmacy", "root", "");
                            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        } catch (PDOException $e) {
                            echo "Connection error: " . $e->getMessage();
                        }
                        return $this->conn;
                    }
                }

                class SalesOrder {
                    private $conn;
                    public $id;
                    public function __construct($db) {
                        $this->conn = $db;
                    }
                    public function delete() {
                        $stmt = $this->conn->prepare("DELETE FROM sales_order WHERE transaction_id = :id");
                        $stmt->bindParam(':id', $this->id);
                        $stmt->execute();
                        return $stmt->rowCount() > 0;
                    }
                }

                class FormHandler {
                    private $db, $salesOrder;
                    public function __construct() {
                        $this->db = (new Database())->getConnection();
                        $this->salesOrder = new SalesOrder($this->db);
                    }
                    public function handleRequest() {
                        if (isset($_GET['id']) && !empty($_GET['id'])) {
                            $this->salesOrder->id = htmlspecialchars($_GET['id']);
                            if ($this->salesOrder->delete()) {
                                header("Location: sales.php");
                                exit();
                            } else {
                                echo "Error deleting record.";
                            }
                        } else {
                            header("Location: sales.php");
                            exit();
                        }
                    }
                }

                (new FormHandler())->handleRequest();

                ?>
            </div>
        </div>
    </div>
</body>
</html>
