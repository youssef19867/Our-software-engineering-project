<!DOCTYPE html>
<html>
<head>
    <link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="sales.css"> <!-- Link to your custom CSS file -->
</head>
<body>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="contentheader">
                    <i class="icon-money"></i> Sales
                </div>
                <div style="margin-top: -19px; margin-bottom: 21px;">
                    
                </div>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <table class="custom-table" id="resultTable">
                        <thead>
                            <tr>
                                <th> Product Code </th>
                                <th> Generic Name </th>
                                <th> Name </th>
                                <th> Price </th>
                                <th> Qty </th>
                                <th> Amount </th>
                                <th> Profit </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="text" name="product_code" required></td>
                                <td><input type="text" name="gen_name" required></td>
                                <td><input type="text" name="name" required></td>
                                <td><input type="number" name="price" min="0" required></td>
                                <td><input type="number" name="qty" min="0" required></td>
                                <td><input type="number" name="amount" min="0" required></td>
                                <td><input type="number" name="profit" min="0" required></td>
                            </tr>
                        </tbody>
                    </table>
                    <button type="submit" class="btn btn-primary">Insert</button>
                </form>
            </div>
        </div>
    </div>

    <?php
   
    class Database {
        private $host = 'localhost';
        private $db_name = 'dr. tarek\'s pharmacy';
        private $username = 'root';
        private $password = '';
        public $conn;

        public function getConnection() {
            $this->conn = null;

            try {
                $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (PDOException $exception) {
                echo "Connection error: " . $exception->getMessage();
            }

            return $this->conn;
        }
    }

    
    class SalesOrder {
        private $conn;
        private $table_name = "sales_order";

        public $product_code;
        public $gen_name;
        public $name;
        public $price;
        public $qty;
        public $amount;
        public $profit;

        public function __construct($db) {
            $this->conn = $db;
        }

        public function create() {
            $query = "INSERT INTO " . $this->table_name . " 
                      SET product_code=:product_code, gen_name=:gen_name, name=:name, 
                          price=:price, qty=:qty, amount=:amount, profit=:profit";

            $stmt = $this->conn->prepare($query);

            $stmt->bindParam(':product_code', $this->product_code);
            $stmt->bindParam(':gen_name', $this->gen_name);
            $stmt->bindParam(':name', $this->name);
            $stmt->bindParam(':price', $this->price);
            $stmt->bindParam(':qty', $this->qty);
            $stmt->bindParam(':amount', $this->amount);
            $stmt->bindParam(':profit', $this->profit);

            if ($stmt->execute()) {
                return true;
            }

            return false;
        }
    }

    // Form handling
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $database = new Database();
        $db = $database->getConnection();

        $salesOrder = new SalesOrder($db);
        $salesOrder->product_code = $_POST['product_code'];
        $salesOrder->gen_name = $_POST['gen_name'];
        $salesOrder->name = $_POST['name'];
        $salesOrder->price = $_POST['price'];
        $salesOrder->qty = $_POST['qty'];
        $salesOrder->amount = $_POST['amount'];
        $salesOrder->profit = $_POST['profit'];

        if ($salesOrder->create()) {
            header("Location: sales.php");
            exit();
        } else {
            
        }
    }
    ?>
</body>
</html>
