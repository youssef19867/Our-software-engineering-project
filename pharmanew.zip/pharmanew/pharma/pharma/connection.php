<?php
$user='root';
$pass= '';
$db='pharmacy';
$conn= new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");
?>