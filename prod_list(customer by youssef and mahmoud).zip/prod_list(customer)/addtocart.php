<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $product_id = $_POST['product_id'];
    $price = $_POST['price'];
    
    // You can set the customer id to 0 by default
    $customer_id = 0; // You may adjust this based on your actual customer identification method

    // Get the current date
    $current_date = date("Y-m-d");

    // Here you can do whatever you want with the retrieved data, like saving it to a database
    // For example, you can connect to your database and execute an SQL query to insert the data
    // Example:
    
    $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "pharmacy";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
// Execute the statement

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

   // Prepare SQL statement
   $stmt = $conn->prepare("INSERT INTO `orderpro`( `pid`, `price`, `date_of_purchase`, `cid`) VALUES (?, ?, ?, ?)");
   if (!$stmt) {
       die("Error in prepare: " . $conn->error);
   }

   // Bind parameters
   $stmt->bind_param("sdss",  $product_id, $price,  $current_date,  $customer_id);

   // Execute SQL statement
   if ($stmt->execute()) {
       header('Location: ' . $_SERVER['HTTP_REFERER']);

       exit();
   } else {
       echo "Error: " . $stmt->error;
   }

   // Close statement
   $stmt->close();
} else {
   echo "Invalid request method";
}

// Close connection
$conn->close();
?>